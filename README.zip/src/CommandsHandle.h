#pragma once

#include <iostream>
#include "NoteRepository.h"
#include "InputHandle.h"
#include "TextUI.h"

enum commands { exit_program = 0, add_new_note = 1, show_list_notes = 2, delete_note = 3 };

class CommandsHandle {

public:

	void Run();

private:
	NoteRepository rep;
	InputHandle inputHandler;
	TextUI ui;

	void AddNewNote();

	void ShowListNotes();

	void DeleteNote();
};